ubuntu Cookbook CHANGELOG
======================
This file is used to list changes made in each version of the ubuntu cookbook.

v1.1.6 (2014-02-14)
-------------------
### New Feature
- **[COOK-4325](https://tickets.opscode.com/browse/COOK-4325)** - allow setting codename as an attribute

### Bug
- **[COOK-3852](https://tickets.opscode.com/browse/COOK-3852)** - Ubuntu receipe triggers an apt-get update before replacing the default sources.list


v1.1.4
------
- COOK-3852 - updating source.list before calling apt-get update
- Style and test harness


v0.0.0
------
Text goes here
